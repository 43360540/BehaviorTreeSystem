using System;

namespace BehaviorTree
{
    public class ConditionLeaf : NodeBase
    {
        private readonly ICondition _condition = null;
        
        public ConditionLeaf(Func<BlackBoardMono, float, bool> condition)
        {
            if (condition == null)
                throw new ArgumentNullException(nameof(condition));
            _condition = new DelegateCondition(condition);
        }

        public ConditionLeaf(ICondition condition)
        {
            _condition = condition ?? throw new ArgumentNullException(nameof(condition));
        }

        public bool Evaluate(BlackBoardMono bb, float dt)
        {
            return _condition.Evaluate(bb, dt);
        }

        protected override NodeStatus OnTick(BlackBoardMono bb, float dt)
        {
            return Evaluate(bb, dt)? NodeStatus.Success : NodeStatus.Failure;
        }
    }
}
