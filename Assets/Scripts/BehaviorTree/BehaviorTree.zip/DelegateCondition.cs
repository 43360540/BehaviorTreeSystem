using System;

namespace BehaviorTree
{
    public sealed class DelegateCondition : ICondition
    {
        private readonly Func<BlackBoardMono, float, bool> _predicate = null;

        public DelegateCondition(Func<BlackBoardMono, float, bool> predicate)
        {
            _predicate = predicate ?? throw new ArgumentNullException(nameof(predicate));
        }

        public bool Evaluate(BlackBoardMono bb, float dt)
        {
            return _predicate.Invoke(bb, dt);
        }
    }
}