using System;

namespace BehaviorTree
{
    public class GuardDecorator : NodeBase, IGuard
    {
        private readonly ICondition _condition = null;
        private readonly INode _child = null;

        public GuardDecorator(Func<BlackBoardMono, float, bool> condition, INode child)
        {
            _child = child ?? throw new ArgumentNullException(nameof(child));
            if (condition == null) 
                throw new ArgumentNullException(nameof(condition));
            _condition = new DelegateCondition(condition);
            
        }

        public GuardDecorator(ICondition condition, INode child)
        {
            _child = child ?? throw new ArgumentNullException(nameof(child));
            _condition = condition ?? throw new ArgumentNullException(nameof(condition));
        }

        public bool IsSelectable(BlackBoardMono bb, float dt)
        {
            return _condition.Evaluate(bb, dt);
        }

        protected override NodeStatus OnTick(BlackBoardMono bb, float dt)
        {
            if (!_condition.Evaluate(bb, dt))
            {
                _child.Abort(bb);
                return NodeStatus.Failure;
            }
            return _child.Tick(bb, dt);
        }

        protected override void OnAbort(BlackBoardMono bb)
        {
            base.OnAbort(bb);
            _child.Abort(bb);
        }

        protected override void OnReset()
        {
            base.OnReset();
            _child.Reset();
        }
    }
}
